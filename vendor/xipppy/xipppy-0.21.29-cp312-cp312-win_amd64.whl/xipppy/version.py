# PATCH_LEVEL is zero for local developer builds and the Jenkins build number
# for Jenkins builds, including the production build.  This is filled in by
# cmake.

xipppy_version = [0, 21, 29]
xipppy_str = "{}.{}.{}".format(*xipppy_version)
